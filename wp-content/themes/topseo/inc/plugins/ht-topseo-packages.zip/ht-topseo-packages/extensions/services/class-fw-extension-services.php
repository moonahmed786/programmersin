<?php if ( ! defined( 'FW' ) ) {
	die( 'Forbidden' );
}

class FW_Extension_SERVICES extends FW_Extension {
  private $post_type = 'ht-service';
  private $slug = 'services';
  private $taxonomy_name = 'ht-service-filter';
  private $taxonomy_slug = 'service-filter';

  public function _init(){
    $this->define_slugs();

    add_action( 'init', array( $this, 'topseo_action_register_post_type' ) );
    add_action( 'init', array( $this, 'topseo_action_register_taxonomy' ) );

	if ( is_admin() ) {
		$this->save_permalink_structure();
		add_action( 'admin_init', array( $this, '_action_add_permalink_in_settings' ) );
	}
  }

  private function define_slugs(){
    $this->slug = $this->get_db_data( 'permalinks/post', $this->slug );

    $this->taxonomy_slug = $this->get_db_data( 'permalinks/taxonomy', $this->taxonomy_slug );
  }

  private function save_permalink_structure() {

		if ( ! isset( $_POST['permalink_structure'] ) && ! isset( $_POST['category_base'] ) ) {
			return;
		}

		$post = FW_Request::POST( 'ht_service_slug', $this->slug );

		$taxonomy = FW_Request::POST( 'ht_service_portfolio_slug',$this->taxonomy_slug );


		$this->set_db_data( 'permalinks/post', $post );
		$this->set_db_data( 'permalinks/taxonomy', $taxonomy );
	}

  /**
	 * @internal
	 **/
	public function _action_add_permalink_in_settings() {
		add_settings_field(
			'ht_service_slug',
			__( 'Service base', 'fw' ),
			array( $this, 'topseo_service_slug' ),
			'permalink',
			'optional'
		);

		add_settings_field(
			'ht_service_portfolio_slug',
			__( 'Service category base', 'fw' ),
			array( $this, 'topseo_service_taxonomy_slug' ),
			'permalink',
			'optional'
		);
	}

	/**
	 * @internal
	 */
	public function topseo_service_slug() {
		?>
		<input type="text" name="ht_service_slug" value="<?php echo $this->slug; ?>">
		<code>/my-service</code>
		<?php
	}

	/**
	 * @internal
	 */
	public function topseo_service_taxonomy_slug() {
		?>
		<input type="text" name="ht_service_portfolio_slug" value="<?php echo $this->taxonomy_slug; ?>">
		<code>/my-service-cate</code>
		<?php
	}

	

  public function topseo_action_register_post_type() {
    $post_names = apply_filters( 'fw_ext_projects_post_type_name',
			array(
				'singular' => __( 'Service', 'topseo' ),
				'plural'   => __( 'Services', 'topseo' )
			) );

		register_post_type( $this->post_type,
			array(
				'labels'             => array(
					'name'               => $post_names['plural'], //__( 'Portfolio', 'topseo' ),
					'singular_name'      => $post_names['singular'], //__( 'Portfolio project', 'topseo' ),
					'add_new'            => __( 'Add New', 'topseo' ),
					'add_new_item'       => sprintf( __( 'Add New %s', 'topseo' ), $post_names['singular'] ),
					'edit'               => __( 'Edit', 'topseo' ),
					'edit_item'          => sprintf( __( 'Edit %s', 'topseo' ), $post_names['singular'] ),
					'new_item'           => sprintf( __( 'New %s', 'topseo' ), $post_names['singular'] ),
					'all_items'          => sprintf( __( 'All %s', 'topseo' ), $post_names['plural'] ),
					'view'               => sprintf( __( 'View %s', 'topseo' ), $post_names['singular'] ),
					'view_item'          => sprintf( __( 'View %s', 'topseo' ), $post_names['singular'] ),
					'search_items'       => sprintf( __( 'Search %s', 'topseo' ), $post_names['plural'] ),
					'not_found'          => sprintf( __( 'No %s Found', 'topseo' ), $post_names['plural'] ),
					'not_found_in_trash' => sprintf( __( 'No %s Found In Trash', 'topseo' ), $post_names['plural'] ),
					'parent_item_colon'  => '' /* text for parent types */
				),
				'description'        => __( 'Create a service item', 'topseo' ),
				'public'             => true,
				'show_ui'            => true,
				'show_in_menu'       => true,
				'show_in_nav_menus' 	=> true,
				'publicly_queryable' => true,
				/* queries can be performed on the front end */
				'has_archive'        => false,
				'rewrite'            => array(
					'slug' => $this->slug
				),
				'menu_position'      => 4,
				'show_in_nav_menus'  => true,
				'menu_icon'          => 'dashicons-clipboard',
				'hierarchical'       => true,
				'query_var'          => true,
				/* Sets the query_var key for this post type. Default: true - set to $post_type */
				'supports'           => array(
					'title', /* Text input field to create a post title. */
					'editor',
					'thumbnail', /* Displays a box for featured image. */
					'excerpt'
				),
				'capabilities'       => array(
					'edit_post'              => 'edit_pages',
					'read_post'              => 'edit_pages',
					'delete_post'            => 'edit_pages',
					'edit_posts'             => 'edit_pages',
					'edit_others_posts'      => 'edit_pages',
					'publish_posts'          => 'edit_pages',
					'read_private_posts'     => 'edit_pages',
					'read'                   => 'edit_pages',
					'delete_posts'           => 'edit_pages',
					'delete_private_posts'   => 'edit_pages',
					'delete_published_posts' => 'edit_pages',
					'delete_others_posts'    => 'edit_pages',
					'edit_private_posts'     => 'edit_pages',
					'edit_published_posts'   => 'edit_pages',
				),
			) );
  }

  public function topseo_action_register_taxonomy() {
    $category_names = apply_filters( 'fw_ext_portfolio_category_name', array(
			'singular' => __( 'Category', 'topseo' ),
			'plural'   => __( 'Categories', 'topseo' )
		) );

		register_taxonomy( $this->taxonomy_name, $this->post_type, array(
			'labels'            => array(
				'name'              => sprintf( _x( 'Service %s', 'taxonomy general name', 'topseo' ), $category_names['plural'] ),
				'singular_name'     => sprintf( _x( 'Service %s', 'taxonomy singular name', 'topseo' ), $category_names['singular'] ),
				'search_items'      => sprintf( __( 'Search %s', 'topseo' ), $category_names['plural'] ),
				'all_items'         => sprintf( __( 'All %s', 'topseo' ), $category_names['plural'] ),
				'parent_item'       => sprintf( __( 'Parent %s', 'topseo' ), $category_names['singular'] ),
				'parent_item_colon' => sprintf( __( 'Parent %s:', 'topseo' ), $category_names['singular'] ),
				'edit_item'         => sprintf( __( 'Edit %s', 'topseo' ), $category_names['singular'] ),
				'update_item'       => sprintf( __( 'Update %s', 'topseo' ), $category_names['singular'] ),
				'add_new_item'      => sprintf( __( 'Add New %s', 'topseo' ), $category_names['singular'] ),
				'new_item_name'     => sprintf( __( 'New %s Name', 'topseo' ), $category_names['singular'] ),
				'menu_name'         => $category_names['plural'],
			),
			'public'            => true,
			'hierarchical'      => true,
			'show_ui'           => true,
			'show_admin_column' => true,
			'query_var'         => true,
			'show_in_nav_menus' => true,
			'show_tagcloud'     => false,
			'rewrite'           => array(
				'slug' => $this->taxonomy_slug
			),
		) );
  }

	public function get_post_type_name() {
		return $this->post_type;
	}

	public function get_taxonomy_name() {
		return $this->taxonomy_name;
	}
}
