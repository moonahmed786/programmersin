<?php if ( ! defined( 'FW' ) ) {
	die( 'Forbidden' );
}

$manifest = array();

$manifest['name']        = __( 'Testimonial', 'topseo' );
$manifest['description'] = __(
	'Testimonials is a extension to display testimonials, reviews or quotes in multiple ways! Fully compatible with the brand new WordPress.',
	'topseo'
);
$manifest['version'] = '1.0';

$manifest['display'] = true;
$manifest['standalone'] = true;
$manifest['thumbnail'] = 'fa fa-commenting';
