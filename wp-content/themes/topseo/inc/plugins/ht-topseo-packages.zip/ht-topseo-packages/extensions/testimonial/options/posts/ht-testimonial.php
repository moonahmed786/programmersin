<?php
/**
 * Option metabox for Recipe post
 * @var array
 * @package topseo
 */

$options = array(
    'metabox' => array(
        'type'     => 'box',
        'title'    => esc_html__( 'Testimonial Settings', 'topseo' ),
        'priority' => 'high',
        'options'  => array(
            'name'  => array(
                'type'  => 'text',
                'label' => esc_attr__( 'Name / Company', 'topseo' ),
            ),
            'position'  => array(
                'type'  => 'text',
                'label' => esc_attr__( 'Position', 'topseo' ),
            ),
            'rating'    => array(
                'type'  => 'short-select',
                'label' => esc_attr('Rating', 'topseo'),
                'value' => '5',
                'choices' => array(
                    '1' => __( '1', 'topseo' ),
                    '2' => __( '2', 'topseo' ),
                    '3' => __( '3', 'topseo' ),
                    '4' => __( '4', 'topseo' ),
                    '5' => __( '5', 'topseo' ),
                )
            )
        )

    )
);