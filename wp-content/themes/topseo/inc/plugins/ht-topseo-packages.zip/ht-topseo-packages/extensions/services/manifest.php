<?php if ( ! defined( 'FW' ) ) {
	die( 'Forbidden' );
}

$manifest = array();

$manifest['name']        = __( 'Services', 'topseo' );
$manifest['description'] = __(
	'A beautiful and professional way to showcase your services or products on your website.',
	'topseo'
);
$manifest['version'] = '1.0';
$manifest['display'] = true;
$manifest['standalone'] = true;
$manifest['thumbnail'] = 'fa fa-server';
