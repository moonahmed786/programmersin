<?php
get_header(); ?>

<p>Under construction!</p>

<?php get_footer(); ?>
