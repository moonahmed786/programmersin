<?php if ( ! defined( 'FW' ) ) {
	die( 'Forbidden' );
}

class FW_Extension_FW_Pending_Mode extends FW_Extension {
	function _init(){

	}
}
